The Stoic Fellowship Meeting Guide: What Is Stoicism?

what-is-stoicism-guide.pdf    Meeting guide booklet. Print double-sided, flip on the short edge, then fold.
what-is-stoicism-guide.docx   The same meeting guide as an editable Word file.
what-is-stoicism-xguide.pdf   Expanded guide for the facilitator: read before the meeting.
what-is-stoicism-primer.pdf   Meeting Primer for members. Online version with a Copy text button:
                 https://stoicfellowship.com/primer/stoicism
what-is-stoicism-card.pdf     Table card. Print on one sheet, fold in half, and stand it on the table.

Event blurb:
What makes a life good? What is actually up to us? Why do some things upset us, and how should we respond? Stoicism has been taking on questions like these for over two thousand years. We’ll hear a short introduction, talk through a few everyday situations, and leave with one simple practice to try. Newcomers welcome; no preparation needed.

The Stoic Fellowship · stoicfellowship.com/meeting-guides
