The Stoic Fellowship Meeting Guide: What’s Actually Good?

whats-actually-good-guide.pdf    Meeting guide booklet. Print double-sided, flip on the short edge, then fold.
whats-actually-good-guide.docx   The same meeting guide as an editable Word file.
whats-actually-good-xguide.pdf   Expanded guide for the facilitator: read before the meeting.
whats-actually-good-primer.pdf   Meeting Primer for members. Online version with a Copy text button:
                 https://stoicfellowship.com/primer/good
whats-actually-good-card.pdf     Table card. Print on one sheet, fold in half, and stand it on the table.

Event blurb:
Most of us want money, health, and a good name. Socrates asked whether any of them actually make a life good, and the Stoics built on his answer. We’ll read a short argument from Plato, test it against real choices, and try a simple question to ask before a decision. Newcomers welcome; no preparation needed.

The Stoic Fellowship · stoicfellowship.com/meeting-guides
