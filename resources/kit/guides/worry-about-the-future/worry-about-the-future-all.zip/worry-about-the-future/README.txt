The Stoic Fellowship Meeting Guide: Worry About the Future

worry-about-the-future-guide.pdf    Meeting guide booklet. Print double-sided, flip on the short edge, then fold.
worry-about-the-future-guide.docx   The same meeting guide as an editable Word file.
worry-about-the-future-xguide.pdf   Expanded guide for the facilitator: read before the meeting.
worry-about-the-future-primer.pdf   Meeting Primer for members. Online version with a Copy text button:
                 https://stoicfellowship.com/primer/worry
worry-about-the-future-card.pdf     Table card. Print on one sheet, fold in half, and stand it on the table.

Event blurb:
Seneca told a worried friend that we suffer more often in imagination than in reality. Was he right? We’ll read from his letter on groundless fears, talk about the difference between planning and worrying, and try a calm, five-minute way of preparing for setbacks. Newcomers welcome; no preparation needed.

The Stoic Fellowship · stoicfellowship.com/meeting-guides
