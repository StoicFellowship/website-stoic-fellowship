On Stoic Living Discussion Series, Guide 1 of 12: When Your Mind Jumps to Conclusions

01-when-your-mind-jumps-to-conclusions-guide.pdf    Meeting guide booklet. Print double-sided, flip on the short edge, then fold.
01-when-your-mind-jumps-to-conclusions-guide.docx   The same meeting guide as an editable Word file.
01-when-your-mind-jumps-to-conclusions-xguide.pdf   Expanded guide for the facilitator: read before the meeting.
01-when-your-mind-jumps-to-conclusions-primer.pdf   Meeting Primer for members. Online version with a Copy text button:
                 https://stoicfellowship.com/primer/osl-01
01-when-your-mind-jumps-to-conclusions-card.pdf     Table card. Print on one sheet, fold in half, and stand it on the table.

Event blurb:
When an email goes unanswered, a conclusion often arrives before we've decided anything: they're ignoring me. This month we'll test one quick conclusion together, using a short reading from Epictetus, and practice giving a judgment no more confidence than its grounds support. No preparation needed; newcomers welcome.

The Stoic Fellowship · stoicfellowship.com/meeting-guides
