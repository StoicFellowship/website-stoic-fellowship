On Stoic Living Discussion Series, Guide 1 of 12: When Your Mind Jumps to Conclusions

01-when-your-mind-jumps-to-conclusions-guide.pdf    Meeting guide booklet. Print double-sided, flip on the short edge, then fold.
01-when-your-mind-jumps-to-conclusions-guide.docx   The same meeting guide as an editable Word file.
01-when-your-mind-jumps-to-conclusions-xguide.pdf   Expanded guide for the facilitator: read before the meeting.
01-when-your-mind-jumps-to-conclusions-primer.pdf   Meeting Primer for members. Online version with a Copy text button:
                 https://stoicfellowship.com/primer/osl-01
01-when-your-mind-jumps-to-conclusions-card.pdf     Table card. Print on one sheet, fold in half, and stand it on the table.

Event blurb:
An unanswered email can seem to tell us more than it does. We’ll discuss what supports a conclusion and test how much confidence it deserves. Newcomers welcome; no preparation needed.

The Stoic Fellowship · stoicfellowship.com/meeting-guides
