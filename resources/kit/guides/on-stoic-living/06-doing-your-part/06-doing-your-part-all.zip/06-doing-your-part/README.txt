On Stoic Living Discussion Series, Guide 6 of 12: Doing Your Part

06-doing-your-part-guide.pdf    Meeting guide booklet. Print double-sided, flip on the short edge, then fold.
06-doing-your-part-guide.docx   The same meeting guide as an editable Word file.
06-doing-your-part-xguide.pdf   Expanded guide for the facilitator: read before the meeting.
06-doing-your-part-primer.pdf   Meeting Primer for members. Online version with a Copy text button:
                 https://stoicfellowship.com/primer/osl-06
06-doing-your-part-card.pdf     Table card. Print on one sheet, fold in half, and stand it on the table.

Event blurb:
Justice asks us to consider what our choices ask of other people and then act on those reasons. We'll rehearse the Justice Check in a familiar situation and choose a response we could defend from either side. Newcomers welcome; no preparation needed.

The Stoic Fellowship · stoicfellowship.com/meeting-guides
