On Stoic Living Discussion Series, Guide 10 of 12: Before You Give In

10-before-you-give-in-guide.pdf    Meeting guide booklet. Print double-sided, flip on the short edge, then fold.
10-before-you-give-in-guide.docx   The same meeting guide as an editable Word file.
10-before-you-give-in-xguide.pdf   Expanded guide for the facilitator: read before the meeting.
10-before-you-give-in-primer.pdf   Meeting Primer for members. Online version with a Copy text button:
                 https://stoicfellowship.com/primer/osl-10
10-before-you-give-in-card.pdf     Table card. Print on one sheet, fold in half, and stand it on the table.

Event blurb:
A tempting pleasure can make its own exception sound reasonable. We'll examine what the attraction promises and test it against a reason worth keeping. Newcomers welcome; no preparation needed.

The Stoic Fellowship · stoicfellowship.com/meeting-guides
