On Stoic Living Discussion Series, Guide 5 of 12: Making Room for Other People

05-making-room-for-other-people-guide.pdf    Meeting guide booklet. Print double-sided, flip on the short edge, then fold.
05-making-room-for-other-people-guide.docx   The same meeting guide as an editable Word file.
05-making-room-for-other-people-xguide.pdf   Expanded guide for the facilitator: read before the meeting.
05-making-room-for-other-people-primer.pdf   Meeting Primer for members. Online version with a Copy text button:
                 https://stoicfellowship.com/primer/osl-05
05-making-room-for-other-people-card.pdf     Table card. Print on one sheet, fold in half, and stand it on the table.

Event blurb:
What we want can leave other people's good out of view. We'll practice widening an ordinary aim while loosening demands for approval or agreement. Newcomers welcome; no preparation needed.

The Stoic Fellowship · stoicfellowship.com/meeting-guides
