On Stoic Living Discussion Series, Guide 2 of 12: When Wanting Turns Into Needing

02-when-wanting-turns-into-needing-guide.pdf    Meeting guide booklet. Print double-sided, flip on the short edge, then fold.
02-when-wanting-turns-into-needing-guide.docx   The same meeting guide as an editable Word file.
02-when-wanting-turns-into-needing-xguide.pdf   Expanded guide for the facilitator: read before the meeting.
02-when-wanting-turns-into-needing-primer.pdf   Meeting Primer for members. Online version with a Copy text button:
                 https://stoicfellowship.com/primer/osl-02
02-when-wanting-turns-into-needing-card.pdf     Table card. Print on one sheet, fold in half, and stand it on the table.

Event blurb:
Wanting something can quietly turn into needing it. This month we'll look at what our wants promise, and practice pursuing what we prefer without letting a good life depend on getting it. Newcomers welcome; no preparation needed.

The Stoic Fellowship · stoicfellowship.com/meeting-guides
