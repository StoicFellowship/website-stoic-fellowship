On Stoic Living Discussion Series, Guide 8 of 12: What Am I Trying Never to Face?

08-what-am-i-trying-never-to-face-guide.pdf    Meeting guide booklet. Print double-sided, flip on the short edge, then fold.
08-what-am-i-trying-never-to-face-guide.docx   The same meeting guide as an editable Word file.
08-what-am-i-trying-never-to-face-xguide.pdf   Expanded guide for the facilitator: read before the meeting.
08-what-am-i-trying-never-to-face-primer.pdf   Meeting Primer for members. Online version with a Copy text button:
                 https://stoicfellowship.com/primer/osl-08
08-what-am-i-trying-never-to-face-card.pdf     Table card. Print on one sheet, fold in half, and stand it on the table.

Event blurb:
What we try hardest to avoid can begin to govern what we are willing to choose. We'll examine an ordinary unwelcome cost and practice giving honesty or fairness greater weight than escape. Newcomers welcome; no preparation needed.

The Stoic Fellowship · stoicfellowship.com/meeting-guides
