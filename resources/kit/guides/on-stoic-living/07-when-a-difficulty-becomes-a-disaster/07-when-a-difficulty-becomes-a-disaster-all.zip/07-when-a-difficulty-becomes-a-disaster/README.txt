On Stoic Living Discussion Series, Guide 7 of 12: When a Difficulty Becomes a Disaster

07-when-a-difficulty-becomes-a-disaster-guide.pdf    Meeting guide booklet. Print double-sided, flip on the short edge, then fold.
07-when-a-difficulty-becomes-a-disaster-guide.docx   The same meeting guide as an editable Word file.
07-when-a-difficulty-becomes-a-disaster-xguide.pdf   Expanded guide for the facilitator: read before the meeting.
07-when-a-difficulty-becomes-a-disaster-primer.pdf   Meeting Primer for members. Online version with a Copy text button:
                 https://stoicfellowship.com/primer/osl-07
07-when-a-difficulty-becomes-a-disaster-card.pdf     Table card. Print on one sheet, fold in half, and stand it on the table.

Event blurb:
A difficulty can make a prediction feel settled before we examine it. We'll test what an ordinary concern actually supports and prepare a judgment worth recalling under pressure. Newcomers welcome; no preparation needed.

The Stoic Fellowship · stoicfellowship.com/meeting-guides
