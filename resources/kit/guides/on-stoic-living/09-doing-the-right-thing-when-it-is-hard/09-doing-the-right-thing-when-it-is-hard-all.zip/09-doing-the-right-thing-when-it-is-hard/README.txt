On Stoic Living Discussion Series, Guide 9 of 12: Doing the Right Thing When It Is Hard

09-doing-the-right-thing-when-it-is-hard-guide.pdf    Meeting guide booklet. Print double-sided, flip on the short edge, then fold.
09-doing-the-right-thing-when-it-is-hard-guide.docx   The same meeting guide as an editable Word file.
09-doing-the-right-thing-when-it-is-hard-xguide.pdf   Expanded guide for the facilitator: read before the meeting.
09-doing-the-right-thing-when-it-is-hard-primer.pdf   Meeting Primer for members. Online version with a Copy text button:
                 https://stoicfellowship.com/primer/osl-09
09-doing-the-right-thing-when-it-is-hard-card.pdf     Table card. Print on one sheet, fold in half, and stand it on the table.

Event blurb:
A difficult responsibility can call for a clear answer before we feel ready to give it. We’ll discuss a trip invitation, compare what is owed, then rehearse an honest response and possible correction. Newcomers welcome; no preparation needed.

The Stoic Fellowship · stoicfellowship.com/meeting-guides
