On Stoic Living Discussion Series, Guide 12 of 12: A Life You Can Sustain

12-a-life-you-can-sustain-guide.pdf    Meeting guide booklet. Print double-sided, flip on the short edge, then fold.
12-a-life-you-can-sustain-guide.docx   The same meeting guide as an editable Word file.
12-a-life-you-can-sustain-xguide.pdf   Expanded guide for the facilitator: read before the meeting.
12-a-life-you-can-sustain-primer.pdf   Meeting Primer for members. Online version with a Copy text button:
                 https://stoicfellowship.com/primer/osl-12
12-a-life-you-can-sustain-card.pdf     Table card. Print on one sheet, fold in half, and stand it on the table.

Event blurb:
Living Stoicism asks how our commitments fit together and what standards guide them. We’ll examine an ordinary request and discuss what temperance asks of a life we can sustain. Newcomers welcome; no preparation needed.

The Stoic Fellowship · stoicfellowship.com/meeting-guides
