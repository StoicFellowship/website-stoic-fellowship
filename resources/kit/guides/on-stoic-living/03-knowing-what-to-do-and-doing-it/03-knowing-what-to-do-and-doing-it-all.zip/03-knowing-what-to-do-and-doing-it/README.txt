On Stoic Living Discussion Series, Guide 3 of 12: Knowing What to Do—and Doing It

03-knowing-what-to-do-and-doing-it-guide.pdf    Meeting guide booklet. Print double-sided, flip on the short edge, then fold.
03-knowing-what-to-do-and-doing-it-guide.docx   The same meeting guide as an editable Word file.
03-knowing-what-to-do-and-doing-it-xguide.pdf   Expanded guide for the facilitator: read before the meeting.
03-knowing-what-to-do-and-doing-it-primer.pdf   Meeting Primer for members. Online version with a Copy text button:
                 https://stoicfellowship.com/primer/osl-03
03-knowing-what-to-do-and-doing-it-card.pdf     Table card. Print on one sheet, fold in half, and stand it on the table.

Event blurb:
What makes a response appropriate, and how can it become a steady habit? We’ll discuss an everyday interruption, compare reasons and responsibilities, then test our understanding by trying possible responses. Newcomers welcome; no preparation needed.

The Stoic Fellowship · stoicfellowship.com/meeting-guides
