On Stoic Living Discussion Series, Guide 4 of 12: Before You Judge Someone

04-before-you-judge-someone-guide.pdf    Meeting guide booklet. Print double-sided, flip on the short edge, then fold.
04-before-you-judge-someone-guide.docx   The same meeting guide as an editable Word file.
04-before-you-judge-someone-xguide.pdf   Expanded guide for the facilitator: read before the meeting.
04-before-you-judge-someone-primer.pdf   Meeting Primer for members. Online version with a Copy text button:
                 https://stoicfellowship.com/primer/osl-04
04-before-you-judge-someone-card.pdf     Table card. Print on one sheet, fold in half, and stand it on the table.

Event blurb:
Judgments about people can outrun what we know about them. We'll examine an ordinary disagreement, separate conduct from what we add, and consider what fairness asks of our judgment. Newcomers welcome; no preparation needed.

The Stoic Fellowship · stoicfellowship.com/meeting-guides
