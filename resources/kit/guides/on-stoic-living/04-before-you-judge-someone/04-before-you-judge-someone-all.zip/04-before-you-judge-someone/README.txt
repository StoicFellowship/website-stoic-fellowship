On Stoic Living Discussion Series, Guide 4 of 12: Before You Judge Someone

04-before-you-judge-someone-guide.pdf    Meeting guide booklet. Print double-sided, flip on the short edge, then fold.
04-before-you-judge-someone-guide.docx   The same meeting guide as an editable Word file.
04-before-you-judge-someone-xguide.pdf   Expanded guide for the facilitator: read before the meeting.
04-before-you-judge-someone-primer.pdf   Meeting Primer for members. Online version with a Copy text button:
                 https://stoicfellowship.com/primer/osl-04
04-before-you-judge-someone-card.pdf     Table card. Print on one sheet, fold in half, and stand it on the table.

Event blurb:
Judging someone fairly requires attention to both conduct and what we add to it. We’ll examine an interruption and compare the judgments its evidence supports. Newcomers welcome; no preparation needed.

The Stoic Fellowship · stoicfellowship.com/meeting-guides
