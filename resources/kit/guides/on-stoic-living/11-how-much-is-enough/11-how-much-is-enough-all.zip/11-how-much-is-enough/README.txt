On Stoic Living Discussion Series, Guide 11 of 12: How Much Is Enough?

11-how-much-is-enough-guide.pdf    Meeting guide booklet. Print double-sided, flip on the short edge, then fold.
11-how-much-is-enough-guide.docx   The same meeting guide as an editable Word file.
11-how-much-is-enough-xguide.pdf   Expanded guide for the facilitator: read before the meeting.
11-how-much-is-enough-primer.pdf   Meeting Primer for members. Online version with a Copy text button:
                 https://stoicfellowship.com/primer/osl-11
11-how-much-is-enough-card.pdf     Table card. Print on one sheet, fold in half, and stand it on the table.

Event blurb:
Wanting more can move the standard of enough before any need has changed. We’ll examine an upgrade offer and compare measures of enough with the wish to choose and use well. Newcomers welcome; no preparation needed.

The Stoic Fellowship · stoicfellowship.com/meeting-guides
