The Stoic Fellowship Meeting Guide: Anger

anger-guide.pdf    Meeting guide booklet. Print double-sided, flip on the short edge, then fold.
anger-guide.docx   The same meeting guide as an editable Word file.
anger-xguide.pdf   Expanded guide for the facilitator: read before the meeting.
anger-primer.pdf   Meeting Primer for members. Online version with a Copy text button:
                 https://stoicfellowship.com/primer/anger
anger-card.pdf     Table card. Print on one sheet, fold in half, and stand it on the table.

Event blurb:
Anger feels like a reaction to what happened. Seneca thought it comes from something we add: a judgment we agree to. We’ll read two short passages from Epictetus and Seneca, look at the moment between the first jolt and what we do next, and leave with a practice for catching it. Newcomers welcome; no preparation needed.

The Stoic Fellowship · stoicfellowship.com/meeting-guides
