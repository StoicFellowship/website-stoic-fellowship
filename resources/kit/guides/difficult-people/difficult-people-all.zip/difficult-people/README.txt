The Stoic Fellowship Meeting Guide: Difficult People

difficult-people-guide.pdf    Meeting guide booklet. Print double-sided, flip on the short edge, then fold.
difficult-people-guide.docx   The same meeting guide as an editable Word file.
difficult-people-xguide.pdf   Expanded guide for the facilitator: read before the meeting.
difficult-people-primer.pdf   Meeting Primer for members. Online version with a Copy text button:
                 https://stoicfellowship.com/primer/people
difficult-people-card.pdf     Table card. Print on one sheet, fold in half, and stand it on the table.

Event blurb:
Marcus Aurelius began some days by reminding himself he would meet rude, ungrateful people, and that he was made to work with them anyway. We’ll read his short morning reflection, talk about what understanding someone does and doesn’t mean, and practice preparing for a hard encounter. Newcomers welcome; no preparation needed.

The Stoic Fellowship · stoicfellowship.com/meeting-guides
