The Stoic Fellowship Meeting Guide: What’s in My Control?

whats-in-my-control-guide.pdf    Meeting guide booklet. Print double-sided, flip on the short edge, then fold.
whats-in-my-control-guide.docx   The same meeting guide as an editable Word file.
whats-in-my-control-xguide.pdf   Expanded guide for the facilitator: read before the meeting.
whats-in-my-control-primer.pdf   Meeting Primer for members. Online version with a Copy text button:
                 https://stoicfellowship.com/primer/control
whats-in-my-control-card.pdf     Table card. Print on one sheet, fold in half, and stand it on the table.

Event blurb:
Some things are up to us and some are not. It sounds simple, yet much of our worry goes to things we can’t decide. We’ll read the opening of Epictetus’s handbook, divide a familiar worry into what is ours and what isn’t, and leave with a one-question practice for the month. Newcomers welcome; no preparation needed.

The Stoic Fellowship · stoicfellowship.com/meeting-guides
